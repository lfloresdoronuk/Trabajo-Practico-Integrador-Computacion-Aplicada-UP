#!/bin/bash

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# De ayuda
if [[ "$1" == "-h" ]]; then
	echo "Uso: $0 [origen] [destino]"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi


# Para verificar los argumentos
if [[ $# -ne 2 ]]; then
	echo "Error: Se necesitan 2 argumentos (origen y destino)"
	exit 1
fi


# Para validar los directorios
if [ ! -d "$ORIGEN" ]; then
	echo "Error: El directorio de origen no existe"
	exit 1
fi 

if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio de destino no existe"
	exit 1
fi

# Si el directorio de origen esta vacio
if [[ -z "$(ls -A "$ORIGEN")" ]]; then
	echo "El directorio de origen esta vacio. No se creo ningun backup"
	exit 1
fi

# Para hacer el BACKUP

BKP_NOMBRE=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
tar -czf "$DESTINO/$BKP_NOMBRE" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

echo "Backup completado: $DESTINO/$BKP_NOMBRE"

