[0;1;32m●[0m apache2.service - The Apache HTTP Server
     Loaded: loaded (/lib/systemd/system/apache2.service; enabled; vendor preset: enabled)
     Active: [0;1;32mactive (running)[0m since Tue 2024-11-19 03:15:37 -03; 7min ago
       Docs: https://httpd.apache.org/docs/2.4/
   Main PID: 20560 (apache2)
      Tasks: 6 (limit: 4661)
     Memory: 12.9M
        CPU: 652ms
     CGroup: /system.slice/apache2.service
             ├─20560 /usr/sbin/apache2 -k start
             ├─20562 /usr/sbin/apache2 -k start
             ├─20563 /usr/sbin/apache2 -k start
             ├─20564 /usr/sbin/apache2 -k start
             ├─20565 /usr/sbin/apache2 -k start
             └─20566 /usr/sbin/apache2 -k start

nov 19 03:15:37 TPServer systemd[1]: Starting The Apache HTTP Server...
nov 19 03:15:37 TPServer apachectl[20559]: AH00558: apache2: Could not reliably determine the server's fully qualified domain name, using 127.0.1.1. Set the 'ServerName' directive globally to suppress this message
nov 19 03:15:37 TPServer systemd[1]: Started The Apache HTTP Server.
